/*
 * InputSignal.cpp
 *
 *  Created on: Sep 29, 2018
 *      Author: chandrika
 *      This is an implementation of the header file of InputSignal.h file.
 */

#include "InputSignal.h"

InputSignal::InputSignal() { // @suppress("Class members should be properly initialized")
	// TODO Auto-generated constructor stub

}

InputSignal::~InputSignal() {
	// TODO Auto-generated destructor stub
}

